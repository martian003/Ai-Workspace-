def authenticate_user(token):
    """Demo only: replace this with verified credentials."""
    return token == "demo-token"
