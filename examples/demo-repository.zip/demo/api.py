from .auth import authenticate_user

def profile(token):
    if not authenticate_user(token):
        return {"error": "unauthorized"}
    return {"name": "Demo user"}
